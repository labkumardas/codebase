// App.js
import React from 'react';
import AppRouter from './component/AppRouter';
  
const App = () => {
  return (
      <AppRouter />
  );
};

export default App;
