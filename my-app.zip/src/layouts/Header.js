import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../component/Navbar';
 
function Header() {
  return (
      <Navbar />
   );
}

export default Header;
