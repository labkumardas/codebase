import React from 'react'

function Pagination() {
    return (
        <div>
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link"  useRef="#" >Previous</a></li>
                    <li class="page-item"><a class="page-link"  useRef="#">1</a></li>
                    <li class="page-item"><a class="page-link"  useRef="#">2</a></li>
                    <li class="page-item"><a class="page-link"  useRef="#">3</a></li>
                    <li class="page-item"><a class="page-link"  useRef="#">Next</a></li>
                </ul>
            </nav>
        </div>
    )
}

export default Pagination
