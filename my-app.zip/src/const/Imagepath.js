import banner from "../assets/images/banner.jpg";
import card from "../assets/images/card.jpg";


const images = {
  banner,
  card

}

export default images;