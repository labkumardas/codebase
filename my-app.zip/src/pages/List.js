import React from 'react'
import Table from '../component/Table'
import Pagination from '../layouts/Pagination'
 function List() {
    return (
        <div className='container'>
            <div className='row'>
            <Table />
            </div>
            <div className='row'>
             <Pagination />
            </div>
        </div>
    )
}

export default List
