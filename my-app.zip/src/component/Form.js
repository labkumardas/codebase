import React from 'react'

const Form = () => {
    return (
         
        <form>
            <div className="form-row">
                <div className="form-group col-md-6">
                    <label for="inputEmail4">Email</label>
                    <input type="email" className="form-control" id="inputEmail4" placeholder="Email" />
                </div>
                <div className="form-group col-md-6">
                    <label for="inputPassword4">Phone</label>
                    <input type="number" className="form-control"   placeholder="Phone" />
                </div>
            </div>
            
           
            <div className="form-row">
                <div className="form-group col-md-6">
                    <label for="inputCity">City</label>
                    <input type="text" className="form-control" id="inputCity" />
                </div>
                <div className="form-group col-md-6">
                    <label for="inputState">State</label>
                    <select id="inputState" className="form-control">
                        <option selected>Choose...</option>
                        <option>...</option>
                    </select>
                </div>
                <div className="form-group col-md-6">
                    <label for="inputZip">Zip</label>
                    <input type="text" className="form-control" id="inputZip" />
                </div>
            </div>
           
            <button type="submit" className="btn btn-primary">Sign in</button>
        </form>
     )
}

export default Form
