import React from 'react';
import Layout from '../layouts/Layout';
 
const Login = () => {
  return (
    <Layout>
      {/* Your page content goes here */}
      <p>Login </p>
    </Layout>
  );
};

export default Login;